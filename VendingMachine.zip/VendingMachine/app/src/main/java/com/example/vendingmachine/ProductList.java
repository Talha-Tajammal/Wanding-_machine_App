package com.example.vendingmachine;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class ProductList extends AppCompatActivity {

    FloatingActionButton addProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_list);

        // Get a reference to the ListView in the layout
        ListView listView = findViewById(R.id.listview);

        // Get the intent that started this activity
        Intent i = getIntent();

        // Check if the intent has the expected extras
        if (i.hasExtra("prdList")) {
            // If the intent has the expected extras, get the ArrayList of Product objects
            ArrayList<Product> list = i.getParcelableArrayListExtra("prdList");

            // Create an adapter to display the list of products in the ListView
            MyAdaptor adapter = new MyAdaptor(this, list);

            // Set the adapter on the ListView
            listView.setAdapter(adapter);
        } else {
            // If the intent does not have the expected extras, log an error and finish the activity
            Log.e("ProductList", "Intent does not contain expected extras");
            finish();
        }

        // Get a reference to the FloatingActionButton in the layout
        addProduct = findViewById(R.id.addProduct);

        // Set a click listener on the FloatingActionButton
        addProduct.setOnClickListener(view -> {
            // Start the ProductCRUD activity when the FloatingActionButton is clicked
            startActivity(new Intent(this, ProductCRUD.class));
        });
    }
}






